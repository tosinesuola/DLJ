
# MedSquad Arena (Deploy Ready)

## Deploy to Netlify
1. Upload this folder to GitHub
2. Go to Netlify → New Site → Import from GitHub
3. Add environment variable:
   ANTHROPIC_API_KEY=your_key_here
4. Deploy

## Features
- Fully working AI question generator
- Secure backend (no exposed API keys)
- Static frontend + serverless function
